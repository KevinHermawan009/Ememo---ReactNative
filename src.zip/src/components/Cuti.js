import DatePicker from 'react-native-datepicker'
import React, { Component } from 'react';
// import { View , StyleSheet , Text , Dimensions, } from 'react-native';
import { View, StyleSheet, Text, Dimensions, TouchableOpacity, ImageBackground, Alert } from 'react-native';
import { Actions } from 'react-native-router-flux';
import { connect } from 'react-redux'

const ScreenWidth = Dimensions.get('window').width;
const ScreenHeight = Dimensions.get('window').height;
const link = 'https://wsdl.maybankfinance.co.id/uat/MAC/InputCuti'


class Cuti extends Component {

    constructor(props) {
        super(props)
        // this.defaultDate = props.defaultDate;
        //this.minDateProp = props.minDate;
        this.state = {
            TanggalCuti: '',
            TanggalAkhirCuti: '',
            username: ''

        }

    }
    submitt = () => {
    
        fetch(link, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'x-api-key': 'IZYXlIljQDpDOdthLa2bq2laqnzlsVpgAv3Wi3Ri'
            },
            body: JSON.stringify({
                "TanggalCuti": this.state.TanggalCuti,
                "TanggalAkhirCuti": this.state.TanggalAkhirCuti,
                "NPK": this.props.username
            })
        })
            .then(response => response.json())
            .then(res => {

                if (res.InputCutiResult == "Berhasil Menyimpan Data") {
                    alert("Berhasil Menyimpan Data")
                    Actions.Tab2()
                }

            })
    }

    back() {
        Actions.Tab2()
    }






    render() {
        return (

            <View >
                <ImageBackground
                    source={require('../image/mamacan.png')}
                    resizeMode='stretch'
                    style={{
                        width: ScreenWidth * 125 / 100,
                        height: ScreenHeight * 70 / 100,
                        right: ScreenWidth * 12 / 100,
                        top: ScreenHeight * 8 / 100
                    }}
                >
                    <View style={{alignItems: 'center'}}>
                        <View style={{
                            alignItems: 'center',
                            width: ScreenWidth * 80 / 100,
                            left: ScreenWidth * 0 / 100,
                            top: ScreenHeight * 12.5 / 100,
                            borderWidth: 0.5,
                            borderRadius: 15,
                            height: ScreenHeight * 27.5 / 100,
                            backgroundColor: '#2E2E2E'

                        }
                        }>
                            <View style={{ backgroundColor: '#2E2E2E', width: ScreenWidth * 70 / 100 }}>
                                <Text style={{
                                    borderBottomColor: 'black',
                                    fontSize: 20, color: 'black',
                                    color: '#fee140'
                                }}>
                                    Tanggal Mulai Cuti
                            </Text>
                            </View>
                            <View style={
                                styles.InputBox
                            }>
                                <DatePicker
                                    style={{ width: ScreenWidth * 40 / 100 }}
                                    date={this.state.TanggalCuti}
                                    mode="date"
                                  
                                    format="YYYY-MM-DD"
                                    minDate={this.minDateProp}
                                    maxDate={this.defaultDate}
                                    confirmBtnText="Confirm"
                                    cancelBtnText="Cancel"
                                    hideText={false}
                                    showIcon={true}
                                    customStyles={{
                                        dateIcon: {
                                            resizeMode: 'stretch',
                                            position: 'absolute',
                                            left:ScreenWidth*57/100

                                        },
                                        placeholderText: {
                                            color: '#957D00',
                                            fontWeight: 'bold',
                                            fontSize: 15,
                                            left: ScreenHeight * 1.5 / 100
                                        },

                                        dateInput: {
                                            width: ScreenWidth * 5 / 100,
                                            borderWidth: 0,
                                            right: ScreenHeight * 4.1 / 100,
                                        }
                                    }}
                                    onDateChange={(date) => { this.setState({ TanggalCuti: date }) }}
                                />

                            </View>
                            <View style={{ backgroundColor: '#2E2E2E', width: ScreenWidth * 70 / 100 }}>
                                <Text style={{ borderBottomColor: 'black', fontSize: 20, color: 'orange' }}>Tanggal Selesai Cuti</Text>
                            </View>



                            <View style={styles.InputBox}>
                                <DatePicker
                                    style={{
                                        width: ScreenWidth * 40 / 100,
                                        height: ScreenHeight * -5 / 100
                                    }}
                                    date={this.state.TanggalAkhirCuti}
                                    mode="date"
                                  
                                    format="YYYY-MM-DD"
                                    minDate={this.minDateProp}
                                    maxDatemaxDate={this.defaultDate}
                                    confirmBtnText="Confirm"
                                    cancelBtnText="Cancel"
                                    hideText={false}
                                    showIcon={true}
                                    customStyles={{
                                        dateIcon: {
                                            resizeMode: 'stretch',
                                            position: 'absolute',
                                            left:ScreenWidth*57/100
                                        },
                                        placeholderText: {
                                            color: '#957D00',
                                            fontWeight: 'bold',
                                            fontSize: 15,
                                            left: ScreenHeight * 1.5 / 100
                                        },
                                        dateInput: {
                                            width: ScreenWidth * 5 / 100,
                                            borderWidth: 0,
                                            right: ScreenHeight * 4.1 / 100,

                                        }
                                    }}
                                    onDateChange={(date) => { this.setState({ TanggalAkhirCuti: date }) }}
                                />
                            </View>                    
                        </View>
                        <TouchableOpacity
                                    style={{
                                        marginTop: ScreenHeight * 13/100,
                                        height: ScreenHeight * 8 / 100,
                                        width: ScreenWidth * 45 / 100,
                                        backgroundColor: '#2E2E2E',
                                        borderColor: '#151515',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        marginLeft: ScreenWidth * 2 / 100,
                                        borderWidth: 1,
                                        borderRadius: 20,
                                    }}
                                    onPress={this.submitt}
                                >
                                        <Text style={{ color: 'yellow' }}>
                                            Submit
                                        </Text>
                                </TouchableOpacity>
                    </View>
                </ImageBackground>
            </View>

        )
    }

}
const styles = StyleSheet.create({
    InputBox: {
        borderWidth: 1,
        borderColor: 'black',
        width: ScreenWidth * 70 / 100,
        height: ScreenHeight * 7 / 100,
        backgroundColor: 'white',
        borderRadius: 5,
        margin: 0.5,
        marginTop: 2,
        justifyContent: 'center',



    },
    btnLogin: {

        height: 40,
        width: 300,
        backgroundColor: '#F8C300',
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: 10,
        left: ScreenWidth * 5 / 100,
        borderRadius: 15,
    },
    container: {
        flex: 1
    },

    backgroundImage: {
        width: ScreenWidth,
        height: ScreenHeight

    },

    MainContainer: {
        flex: 1,
        margin: 10

    },

    TextInputStyle: {
        backgroundColor: '#FFF',
        textAlign: 'center',
        marginLeft: 10,
        height: 50,
        width: 300,
        height: 40,
        borderRadius: 15,
        borderColor: '#F8C300',
        borderWidth: 3,
        marginBottom: 10,
    },
    submitButtonText: {
        color: 'white'
    }
});

function mapStateToProps(state) {
    return {
        username: state.username,
    }
}
function mapDispatchToProps(dispatch) {
    return {

    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Cuti)
