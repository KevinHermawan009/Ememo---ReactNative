import React , { Component } from 'react';
import Icon from 'react-native-vector-icons/FontAwesome';
import { View } from 'native-base';
export default class Tabicon2 extends Component {
    render() {
        return (
            <Icon name = "home" style={{color:'#fee140'}} size={30} />
        )
    }
    render() {
        return (
            
            <View>
                <Icon name = "calendar" style={{color:'#fee140'}} size={30}/>
       
                 
                </View>
        )
    }
}