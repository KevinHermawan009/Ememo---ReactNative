import React , { Component } from 'react';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Text } from 'react-native';
import { View } from 'native-base';

export default class TabIcon4 extends Component {
    render() {
        return (
            <Icon name = "history" style={{color:'#fee140'}} size={30} />
        )
    }
}