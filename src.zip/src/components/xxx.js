import React, { Component } from 'react';
// import { View , ImageBackground , ,TextInput, TouchableOpacity  ,StyleSheet ,Picker, Text , Dimensions } from 'react-native';
import { View, Dimensions, ImageBackground, Image, Text, Alert, TouchableOpacity, ScrollView, Platform,
  StyleSheet, } from 'react-native';
// import { Actions } from 'react-native-router-flux';
import Icon from 'react-native-vector-icons/FontAwesome';
import BottomNavigation, { FullTab } from 'react-native-material-bottom-navigation';
import Login from './login';
import { connect } from 'react-redux';
import { setUsername } from '../Redux/Action';
import ImagePicker from 'react-native-image-picker'
import Modal from 'react-native-modal'

const ScreenWidth = Dimensions.get('window').width;
const ScreenHeight = Dimensions.get('window').height;
const link = 'https://wsdl.maybankfinance.co.id/uat/MAC/Dashboard'


class Register extends Component {

  constructor(props) {
    super(props);
    this.state = {
      lblSalesHariini: '',
      lblSalesbulanini: '',
      name: '',
      jobposition: '',
      officelocation: '',
      description: '',
      email: '',
      telepon: '',
      foto: '',
      visible1: false,
      visible2: false
    }

    this.openModal = this.openModal.bind(this)
    this.closeModal = this.closeModal.bind(this)
  }

  loginp = () => {
    this.setState({ spinner: false });
    Actions.login()
  }

  componentDidMount() {
    fetch(link, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'IZYXlIljQDpDOdthLa2bq2laqnzlsVpgAv3Wi3Ri'
      },
      body: JSON.stringify({
        "Username": this.props.username,
        "Password": this.props.password,
        "SubSystemID": this.props.subsystemid

      })
    })
      .then(response => response.json())
      .then(res => {
        this.setState({
          lblSalesHariini: res.GetDataDashboardResult.lblSalesHariini,
          lblSalesbulanini: res.GetDataDashboardResult.lblSalesbulanini,
          lblmemberonline: res.GetDataDashboardResult.lblmemberonline,
          lblonlinePerbulan: res.GetDataDashboardResult.lblonlinePerbulan,
          lblvisitor: res.GetDataDashboardResult.lblvisitor,
        })


      })

    
  }

  closeModal() {
    this.setState({
      visible1: false,
      visible2: false,
    })
  }

  openModal() {
    this.setState({
      visible1: true,
    })
  }

  Modal1(){ 
    if(this.state.visible1== true){
      return(
        <Modal isVisible={this.state.visible1} onBackdropPress={this.closeModal}>
          <View style={{width: ScreenWidth * 90/100, height: ScreenHeight * 90/100, backgroundColor: 'white', alignSelf: 'center'}}>
          <View style={{alignItems:'center',top:ScreenHeight*83/100,borderWidth:0.5,width:ScreenWidth*30/100,left:ScreenWidth*30/100,borderRadius:15,height:ScreenHeight*5/100  ,backgroundColor:"gray"}}>
            <TouchableOpacity onPress={this.closeModal}>
              <Text style={{color:'blue'}}>BACK</Text>
            </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )
    }
  }
  render() {
    return (
      <View>
        
          <View style={{ backgroundColor: 'white', width:ScreenWidth, height:ScreenHeight}}>
         
            <ScrollView>
            <View style={styles.View1}>
        
                </View>
                <View style={{
                   width: ScreenWidth * 45 / 100,
                   height: ScreenHeight * 20 / 100,
                   top:ScreenHeight*-175/100,
                   backgroundColor:'#2E2E2E',borderRadius: 30, borderWidth: 0.1,borderColor:'#2E2E2E',left:ScreenWidth*15/100}}>
                  <TouchableOpacity
                    style={{ borderRadius: 30, borderWidth: 0.5, width: ScreenWidth * 45 / 100, height: ScreenHeight * 20 / 100, top: ScreenHeight * 0 / 100, borderColor: '#2E2E2E', backgroundColor: '#2E2E2E', alignItems: 'center' }}
                    onPress={
                      this.openModal
                    }>
                    <Icon name="line-chart" style={{
                      color: '#FF8C00',
                      top: ScreenHeight * 8 / 100
                    }}
                      size={30}
                    />
                    <Text style={{ top: ScreenHeight * 8 / 100, fontSize: 15, color: '#FF8C00' }}>Penjualan</Text> 
                
                  </TouchableOpacity>
                  {this.Modal1()}
                  </View> 
                  <View style={{
                   width: ScreenWidth * 45 / 100,
                   height: ScreenHeight * 20 / 100,
                   top:ScreenHeight*-175/100,
                   backgroundColor:'#2E2E2E',borderRadius: 30, borderWidth: 0.1,borderColor:'#2E2E2E',left:ScreenWidth*15/100}}>
                  <TouchableOpacity
                    style={{ borderRadius: 30, borderWidth: 0.5, width: ScreenWidth * 45 / 100, height: ScreenHeight * 20 / 100, top: ScreenHeight * 0 / 100, borderColor: '#2E2E2E', backgroundColor: '#2E2E2E', alignItems: 'center' }}
                    onPress={
                      this.openModal
                    }>
                    <Icon name="line-chart" style={{
                      color: '#FF8C00',
                      top: ScreenHeight * 8 / 100
                    }}
                      size={30}
                    />
                    <Text style={{ top: ScreenHeight * 8 / 100, fontSize: 15, color: '#FF8C00' }}>Penjualan</Text> 
                
                  </TouchableOpacity>
                  {this.Modal1()}
                  </View> 
                  <View style={{
                   width: ScreenWidth * 45 / 100,
                   height: ScreenHeight * 20 / 100,
                   top:ScreenHeight*-175/100,
                   backgroundColor:'#2E2E2E',borderRadius: 30, borderWidth: 0.1,borderColor:'#2E2E2E',left:ScreenWidth*15/100}}>
                  <TouchableOpacity
                    style={{ borderRadius: 30, borderWidth: 0.5, width: ScreenWidth * 45 / 100, height: ScreenHeight * 20 / 100, top: ScreenHeight * 0 / 100, borderColor: '#2E2E2E', backgroundColor: '#2E2E2E', alignItems: 'center' }}
                    onPress={
                      this.openModal
                    }>
                    <Icon name="line-chart" style={{
                      color: '#FF8C00',
                      top: ScreenHeight * 8 / 100
                    }}
                      size={30}
                    />
                    <Text style={{ top: ScreenHeight * 8 / 100, fontSize: 15, color: '#FF8C00' }}>Penjualan</Text> 
                
                  </TouchableOpacity>
                  {this.Modal1()}
                  </View> 
                 
                  
                  <View style={{ borderRadius: 30, borderWidth: 0.5, width: ScreenWidth * 45 / 100, height: ScreenHeight * 20 / 100,bottom:ScreenHeight*195/100, left: ScreenWidth *64 / 100, borderColor: '#2E2E2E', backgroundColor: '#2E2E2E', alignItems: 'center' }}>
                  <TouchableOpacity
                   style={{ borderRadius: 30, borderWidth: 0.5, width: ScreenWidth * 45 / 100, height: ScreenHeight * 20 / 100, top: ScreenHeight * 0/ 100, borderColor: '#2E2E2E', backgroundColor: '#2E2E2E', alignItems: 'center' }}
                    onPress={
                      this.login
                    }>
                    <Icon name="line-chart" style={{
                      color: '#FFD700',
                      top: ScreenHeight * 8 / 100
                    }}
                      size={30}
                    />

                    <Text style={{ top: ScreenHeight * 8 / 100, fontSize: 15, color: '#FFD700' }}>Penjualan</Text>
                    </TouchableOpacity>
                  </View>
               
               
                  <View style={{  borderWidth: 2,
                  height:ScreenHeight*40/100,
                  width:ScreenWidth*95/100,
                  borderColor: '#2E2E2E',
                  borderRadius: 10,
                 
                  }}>

                  <View style={{top:ScreenHeight*2/100}}>
                    <View>
                      <Icon name="user" style={{
                        color: '#2E2E2E',
                        left: ScreenWidth * 6.5 / 100
                      }}
                        size={30}
                      />
                      <View style={{
                        left: ScreenHeight * 9 / 100,
                        top: ScreenHeight * -3 / 100,
                        flexDirection: 'row',
                      }}>
                        <Text Text style={{ color: '#2E2E2E' }} >
                          Member Online Hari Ini:
                  </Text>
                        <Text style={{
                          color: '#2E2E2E',
                          left: ScreenWidth * 1.5 / 100
                        }}>
                          {this.state.lblmemberonline}
                        </Text>
                      </View>
                    </View>
                    <View>
                      <Icon name="group" style={{
                        color: '#2E2E2E',
                        left: ScreenWidth * 5 / 100
                      }}
                        size={30}
                      />
                      <View style={{
                        left: ScreenHeight * 9 / 100,
                        top: ScreenHeight * -3 / 100,
                        flexDirection: 'row',
                      }}>
                        <Text Text style={{ color: '#2E2E2E' }}>
                          Member Online Bulan Ini:
                  </Text>
                        <Text style={{
                          color: '#2E2E2E',
                          left: ScreenWidth * 1.5 / 100
                        }} >
                          {this.state.lblonlinePerbulan}
                        </Text>
                      </View>
                    </View>

                    <View>
                      <Icon name="users" style={{
                        color: '#2E2E2E',
                        left: ScreenWidth * 5 / 100
                      }}
                        size={30}
                      />
                      <View style={{
                        left: ScreenHeight * 9 / 100,
                        top: ScreenHeight * -3 / 100,
                        flexDirection: 'row',

                      }}>
                        <Text style={{ color: '#2E2E2E' }}>
                          Jumlah Visitor:
                  </Text>
                        <Text style={{
                          color: '#2E2E2E',
                          left: ScreenWidth * 1.5 / 100
                        }} >
                          {this.state.lblvisitor}
                        </Text>
                      </View>
                    </View>
                    <View>
                      <Icon name="automobile" style={{
                        color: '#2E2E2E',
                        left: ScreenWidth * 5 / 100
                      }}
                        size={30}
                      />
                      <View style={{
                        left: ScreenHeight * 9 / 100,
                        top: ScreenHeight * -3 / 100,
                        flexDirection: 'row'
                      }}>
                        <Text Text style={{ color: '#2E2E2E' }}>
                          Sales Hari Ini:
                  </Text>
                        <Text style={{
                          color: '#2E2E2E',
                          left: ScreenWidth * 1.5 / 100
                        }} >
                          {this.state.lblSalesHariini}
                        </Text>
                      </View>
                    </View>

                    <View>
                      <Icon name="automobile" style={{
                        color: '#2E2E2E',
                        left: ScreenWidth * 5 / 100
                      }}
                        size={30}
                      />
                      <View style={{
                        left: ScreenHeight * 9 / 100,
                        top: ScreenHeight * -3 / 100,
                        flexDirection: 'row'
                      }}>
                        <Text style={{
                          color: '#2E2E2E'
                        }}>
                          Sales Bulan Ini:
                  </Text>
                        <Text style={{
                          color: '#2E2E2E',
                          left: ScreenWidth * 1.5 / 100
                        }}>
                          {this.state.lblSalesbulanini}
                        </Text>
                      </View>
                    </View>
                    </View>
                </View>
                </ScrollView>

          </View>
        
      </View>
    );
  }
}
const styles = StyleSheet.create({
Backgroundstyle: {
  width: ScreenWidth * 125 / 100,
  height: ScreenHeight * 100 / 100,
  right: ScreenWidth * 12 / 100,
  top: ScreenHeight * 0 / 100,
  backgroundColor: 'transparent'
},

View1: {
    
  width: ScreenWidth,
  height: ScreenHeight * 150 / 100,
  left: ScreenWidth * 12 / 100,
  backgroundColor: 'transparent',
  flexDirection: 'row',
  flex: 1

},
})
function mapStateToProps(state) {
  return {
    username: state.username,
    password: state.password,
    subsystemid: state.subsystemid,
  }
}
function mapDispatchToProps(dispatch) {
  return {

  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Register)