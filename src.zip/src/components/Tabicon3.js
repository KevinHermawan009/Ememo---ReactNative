import React , { Component } from 'react';
import Icon from 'react-native-vector-icons/FontAwesome';
import { View } from 'native-base';
export default class Tabicon3 extends Component {
    
    render() {
        return (
            <Icon name = "home" style={{color:'#fee140'}} size={30} />
        )
    }
}