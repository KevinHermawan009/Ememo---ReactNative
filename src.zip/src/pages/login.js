import React, { Component } from 'react';
import { KeyboardAvoidingView, AsyncStorage, View, ProgressBarAndroid, ImageBackground, TextInput, TouchableOpacity, StyleSheet, Text, Dimensions, borderColor, borderWidth, screens, Alert } from 'react-native';
import { Actions } from 'react-native-router-flux'
import { connect } from 'react-redux';
import { setUsername, setPassword, setSubSystemID, setPasswordDecrypt } from '../Redux/Action';
import Spinner from 'react-native-loading-spinner-overlay'

const ScreenWidth = Dimensions.get('window').width;
const ScreenHeight = Dimensions.get('window').height;
const link = 'https://wsdl.maybankfinance.co.id/uat/MAC/Login'



class Login extends Component {
    constructor(props) {
        super(props)
        this.state = {
            spinner: false,
            progress: 0,
            // login_username: '187360',
            // login_password: 'Astrilogy.id',
        }
        this.checkLogin = this.checkLogin.bind(this);
    }

    login = () => {
        this.setState({ spinner: false });
        Actions.Tab3()
    }

    componentDidMount() {
        this.checkLogin();
    }

    saveKey = async ( value ) => {
        try {
            // console.log(this.props.login_username)
            // console.log(this.props.PasswordDecrypt)
            // console.log(this.props.SubSystemID)
            AsyncStorage.setItem('key1', this.state.login_username);
            AsyncStorage.setItem('key2', this.state.login_password);
            AsyncStorage.setItem('key3', value);
            // AsyncStorage.setItem('key4', value);
        } catch (error) {
            console.log("Error saving data" + error);
        }
    }
    checkLogin = async () => {
        
        try {
            const value = await AsyncStorage.getItem('key1');
            const value1 = await AsyncStorage.getItem('key2');
            const value2 = await AsyncStorage.getItem('key3');
            const value3 = await AsyncStorage.getItem('key4');
            console.log("F", value)

            if (value != null) {
               
                this.props.setUsername(value)
                this.props.setPassword(value1)
                this.props.setSubSystemID(value2)
                this.props.setPasswordDecrypt(value3)
                Actions.Tab3()
            } else {
                // // Actions.login()
                // Alert.alert('TAIK')
            }
        } catch (error) {
            console.log("Error retrieving data" + error);
        }
    }

    loginPressed = () => {
        this.setState({ spinner: true });
        setInterval(() => {
            if (this.state.spinner == true) {
                this.setState({ spinner: false })
            }
        }, 2000);
        fetch(link, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'x-api-key': 'IZYXlIljQDpDOdthLa2bq2laqnzlsVpgAv3Wi3Ri'
            },
            body: JSON.stringify({
                "Username": this.state.login_username,
                "Password": this.state.login_password
                
            })
        })
            .then(response => response.json())
            .then(res => {

                console.log(res)
                if (res.LoginResult.Retval == "Success") {
                    console.log(res)

                    AsyncStorage.setItem('key1', this.state.login_username);
                    AsyncStorage.setItem('key2', this.state.login_password);
                    AsyncStorage.setItem('key3', res.LoginResult.SubSystemID);
                    AsyncStorage.setItem('key4', res.LoginResult.PasswordDecrypt);

                    this.props.setUsername(this.state.login_username)
                    this.props.setPassword(this.state.login_password)
                    this.props.setSubSystemID(res.LoginResult.SubSystemID)
                    this.props.setPasswordDecrypt(res.LoginResult.PasswordDecrypt)

                    this.login()
                }
                else {
                    Alert.alert("your username or password must be wrong")
                }
            })
            .catch((error) => {
                console.error(error);

            });
    }


    render() {
        return (
            <KeyboardAvoidingView style={styles.container} behavior="position" enabled>

                <Spinner visible={this.state.spinner} />

                <View>

                    <ImageBackground
                        style={{
                            width: ScreenWidth * 100 / 100,
                            height: ScreenHeight * 100 / 100,
                        }}
                        source={require('../image/pict12.jpg')}>
                        <View style={{
                            justifyContent: "center",
                            alignItems: "center",

                        }}>
                            <View
                                style={{ alignItems: 'center' }}>
                                <ImageBackground style={{ width: ScreenWidth * 53 / 100, height: ScreenHeight * 30 / 100, top: ScreenHeight * 25 / 100 }} source={require('../image/gambar5.png')} resizeMode='stretch'>
                                </ImageBackground>

                                <View style={{ marginTop: 220 }}>

                                    <TextInput

                                        ref='npk'
                                        placeholder="Enter NPK"

                                        returnKeyType={"next"}
                                        underlineColorAndroid="transparent"
                                        style={styles.TextInputStyle}
                                        onChangeText={
                                            (text) => { this.setState({ login_username: text }) }
                                        }
                                    />
                                    <TextInput

                                        ref='password'
                                        placeholder="Enter Password"
                                        secureTextEntry={true}
                                        returnKeyType={"next"}
                                        underlineColorAndroid="transparent"
                                        style={styles.TextInputStyle}
                                        onChangeText={
                                            (text) => { this.setState({ login_password: text }) }
                                        }
                                    />
                                </View>



                                <TouchableOpacity
                                    style={styles.btnLogin}
                                    onPress={
                                        this.loginPressed
                                    }>
                                    <Text style={{ color: 'black' }}> Login </Text>
                                </TouchableOpacity>

                            </View>

                        </View>



                    </ImageBackground>
                </View>
            </KeyboardAvoidingView>
        )
    }
}


const styles = StyleSheet.create({
    btnLogin: {

        height: ScreenHeight * 6 / 100,
        width: ScreenWidth * 75 / 100,
        backgroundColor: '#F8C300',
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft: ScreenWidth * 2 / 100,
        borderRadius: 15,


    },
    container: {
        flex: 1
    },

    backgroundImage: {
        width: ScreenWidth,
        height: ScreenHeight,


    },

    MainContainer: {
        flex: 1,
        margin: 10

    },

    TextInputStyle: {
        backgroundColor: '#FFF',
        textAlign: 'center',
        marginLeft: ScreenWidth * 2 / 100,

        height: ScreenHeight * 6 / 100,
        width: ScreenWidth * 75 / 100,


        borderRadius: 15,
        borderColor: '#F8C300',
        borderWidth: 2,
        marginBottom: ScreenWidth * 2 / 100,

    },
    submitButtonText: {
        color: 'white'
    }



});

function mapStateToProps(state) {
    return {
        //subsystemid: state.subsystemid,
    }
}

function mapDispatchToProps(dispatch) {
    return {
        setUsername: (username) => {
            dispatch(setUsername(username))
        },
        setPassword: (password) => {
            dispatch(setPassword(password))
        },
        setSubSystemID: (subsystemid) => {
            dispatch(setSubSystemID(subsystemid))
        },
        setPasswordDecrypt: (PasswordDecrypt) => {
            dispatch(setPasswordDecrypt(PasswordDecrypt))
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Login)