import React, { Component } from 'react';
// import { View , ImageBackground , ,TextInput, TouchableOpacity  ,StyleSheet ,Picker, Text , Dimensions } from 'react-native';
import {
  View, Dimensions, ImageBackground, Image, Text, Alert, TouchableOpacity, ScrollView, Platform,
  StyleSheet,
} from 'react-native';
// import { Actions } from 'react-native-router-flux';
import Icon from 'react-native-vector-icons/FontAwesome';
import BottomNavigation, { FullTab } from 'react-native-material-bottom-navigation';
import Login from './login';
import { connect } from 'react-redux';
import { setUsername, setPassword, setSubSystemID } from '../Redux/Action';
import ImagePicker from 'react-native-image-picker'
import Modal from 'react-native-modal'
import NumberFormat from 'react-number-format';

const ScreenWidth = Dimensions.get('window').width;
const ScreenHeight = Dimensions.get('window').height;
const link = 'https://wsdl.maybankfinance.co.id/uat/MAC/Dashboard'


class Register extends Component {

  constructor(props) {
    super(props);
    this.state = {
      lblSalesHariini: '',
      lblSalesbulanini: '',
      name: '',
      jobposition: '',
      officelocation: '',
      description: '',
      email: '',
      telepon: '',
      foto: '',
      visible1: false,
      visible2: false,
      TotalSalesbulan: '',
      username: this.props.username,
      password: this.props.password,
      subsys: this.props.subsystemid,
    }

    this.openModal = this.openModal.bind(this)
    this.closeModal = this.closeModal.bind(this)
  }

  loginp = () => {
    this.setState({ spinner: false });
    Actions.login()
  }

  componentDidMount() {
    
    console.log("username",this.props.username)
    console.log("PW",this.props.password)
    console.log("SUB",this.props.subsystemid)
    // Alert.alert(this.props.pwDecrypt)
    //alert(this.props.password)
    fetch(link, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'x-api-key': 'IZYXlIljQDpDOdthLa2bq2laqnzlsVpgAv3Wi3Ri'
      },
      body: JSON.stringify({
        "Username": this.props.username,
        "Password": this.props.pwDecrypt,
        "SubSystemID": this.props.subsystemid
      })
    })
      .then(response => response.json())
      .then(res => {
        console.log(res)
        this.setState({
          lblSalesHariini: res.GetDataDashboardResult.lblSalesHariini,
          lblSalesbulanini: res.GetDataDashboardResult.lblSalesbulanini,
          lblmemberonline: res.GetDataDashboardResult.lblmemberonline,
          lblonlinePerbulan: res.GetDataDashboardResult.lblonlinePerbulan,
          lblvisitor: res.GetDataDashboardResult.lblvisitor,
          TotalSalesbulan: res.GetDataDashboardResult.TotalSalesbulan

        })


      })


  }

  closeModal() {
    this.setState({
      visible1: false,
      visible2: false,
    })
  }

  openModal() {
    this.setState({
      visible1: true,
    })
  }

  Modal1() {
    if (this.state.visible1 == true) {
      return (
        <Modal isVisible={this.state.visible1} onBackdropPress={this.closeModal}>
          <View style={{ width: ScreenWidth * 90 / 100, height: ScreenHeight * 90 / 100, backgroundColor: 'white', alignSelf: 'center' }}>
            <View style={{ alignItems: 'center', top: ScreenHeight * 83 / 100, borderWidth: 0.5, width: ScreenWidth * 30 / 100, left: ScreenWidth * 30 / 100, borderRadius: 15, height: ScreenHeight * 5 / 100, backgroundColor: "gray" }}>
              <TouchableOpacity onPress={this.closeModal}>
                <Text style={{ color: 'blue' }}>BACK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )
    }
  }
  render() {
    return (
      <View>
        <ImageBackground
          source={require('../image/mamacan.png')}
          resizeMode="stretch"
          style={{
            width: ScreenWidth * 125 / 100,
            height: ScreenHeight * 70 / 100,
            right: ScreenWidth * 12 / 100,
            top: ScreenHeight * 8 / 100,
          }}>


          <View style={{ width: ScreenWidth, height: ScreenHeight, left: ScreenWidth * 12 / 100, bottom: ScreenHeight * 7.5 / 100 }}>

            <ScrollView>

              <View style={{ height: ScreenHeight, width: ScreenWidth, backgroundColor: 'transparent' }} >


                <View style={{
                  width: ScreenWidth * 45 / 100,
                  height: ScreenHeight * 15 / 100,
                  top: ScreenHeight * 14 / 100,
                  backgroundColor: '#38383B', borderRadius: 20, borderWidth: 0.1, borderColor: '#38383B', left: ScreenWidth * 4 / 100, alignItems: 'center'
                }}>

                  <Icon name="user" style={{
                    color: '#fee140',
                    top: ScreenHeight * 4.5 / 100,
                    right: ScreenWidth * 10 / 100
                  }}
                    size={40}
                  />

                  <View style={{ width: ScreenWidth * 30 / 100, alignItems: 'center', bottom: ScreenHeight * 1.4 / 100, left: ScreenWidth * 7.7 / 100 }}>
                    <Text style={{ top: ScreenHeight * 0 / 100, fontSize: 9, color: '#fee140' }}> {this.state.lblmemberonline}</Text>

                    <Text style={{ top: ScreenHeight * 0 / 100, fontSize: 9, color: '#fee140' }}>Member online</Text>

                  </View>
                  <View style={{ width: ScreenWidth * 30 / 100, alignItems: 'center', bottom: ScreenHeight * 1.4 / 100 }}>

                    <Text style={{ top: ScreenHeight * 0 / 100, fontSize: 9, color: '#fee140', left: ScreenWidth * 7.7 / 100 }}> hari ini</Text>
                  </View>



                  {this.Modal1()}
                </View>

                <View style={{
                  width: ScreenWidth * 45 / 100,
                  height: ScreenHeight * 15 / 100,
                  top: ScreenHeight * 15 / 100,
                  backgroundColor: '#38383B', borderRadius: 20, borderWidth: 0.1, borderColor: '#38383B', left: ScreenWidth * 4 / 100, alignItems: 'center'
                }}>

                  <Icon name="automobile" style={{
                    color: '#fee140',
                    top: ScreenHeight * 4.5 / 100,
                    right: ScreenWidth * 10 / 100
                  }}
                    size={40}
                  />

                  <View style={{ width: ScreenWidth * 30 / 100, alignItems: 'center', bottom: ScreenHeight * 1.3 / 100, left: ScreenWidth * 7.7 / 100 }}>
                    <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140', bottom: ScreenHeight * 2 / 100 }}>  {this.state.lblSalesHariini}</Text>


                    <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140', bottom: ScreenHeight * 2 / 100 }}> Sales hari ini</Text>
                  </View>




                </View>
                <View style={{
                  width: ScreenWidth * 45 / 100,
                  height: ScreenHeight * 15 / 100,
                  top: ScreenHeight * 0 / 100,
                  backgroundColor: '#38383B', borderRadius: 20, borderWidth: 0.1, borderColor: '#38383B', left: ScreenWidth * 51 / 100, alignItems: 'center'
                }}>

                  <Icon name="automobile" style={{
                    color: '#fee140',

                    top: ScreenHeight * 4.5 / 100,
                    right: ScreenWidth * 10 / 100
                  }}
                    size={40}
                  />

                  <View style={{ width: ScreenWidth * 30 / 100, alignItems: 'center', bottom: ScreenHeight * 1.3 / 100, left: ScreenWidth * 7.7 / 100 }}>
                    <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140' }}>  {this.state.lblSalesbulanini}</Text>
                    <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140' }}> Sales bulan ini</Text>
                  </View>


                </View>
                <View style={{
                  width: ScreenWidth * 45 / 100,
                  height: ScreenHeight * 15 / 100,
                  top: ScreenHeight * -31 / 100,
                  backgroundColor: '#38383B', borderRadius: 20, borderWidth: 0.1, borderColor: '#38383B', left: ScreenWidth * 51 / 100, alignItems: 'center'
                }}>

                  <Icon name="group" style={{
                    color: '#fee140',
                    top: ScreenHeight * 4.9 / 100,
                    right: ScreenWidth * 10 / 100
                  }}
                    size={40}
                  />

                  <View style={{ width: ScreenWidth * 30 / 100, alignItems: 'center', left: ScreenWidth * 7.7 / 100, bottom: ScreenHeight * 2.5 / 100 }}>
                    <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140' }}> {this.state.lblonlinePerbulan}</Text>
                    <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140' }}>Member online</Text>

                  </View>
                  <View style={{ width: ScreenWidth * 30 / 100, alignItems: 'center', left: ScreenWidth * 7.7 / 100, bottom: ScreenHeight * 2.5 / 100 }}>

                    <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140' }}> bulan ini</Text>
                  </View>



                </View>
                <View style={{
                  width: ScreenWidth * 45 / 100,
                  height: ScreenHeight * 15 / 100,
                  bottom: ScreenHeight * 14 / 100,
                  backgroundColor: '#38383B', borderRadius: 20, borderWidth: 0.1, borderColor: '#38383B', left: ScreenWidth * 51 / 100, alignItems: 'center'
                }}>

                  <Icon name="usd" style={{
                    color: '#fee140',
                    top: ScreenHeight * 4.5 / 100,
                    right: ScreenWidth * 10 / 100
                  }}
                    size={45}
                  />

                  <View style={{ width: ScreenWidth * 30 / 100, alignItems: 'center', bottom: ScreenHeight * 3 / 100, left: ScreenWidth * 7.7 / 100 }}>

                    <NumberFormat
                      value={this.state.TotalSalesbulan}
                      thousandSeparator={true}
                      displayType={'text'}
                      fixedDecimalScale={true}
                      decimalScale={2}
                      renderText={value => <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140', bottom: ScreenHeight * 2 / 100 }}>Rp.{value}</Text>} />



                    <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140', bottom: ScreenHeight * 2 / 100 }}> Total sales</Text>
                  </View>
                  <View style={{ width: ScreenWidth * 30 / 100, alignItems: 'center', bottom: ScreenHeight * 3 / 100, left: ScreenWidth * 7.7 / 100 }}>
                    <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140', bottom: ScreenHeight * 2 / 100 }}> bulan ini</Text>
                  </View>


                </View>
                <View style={{
                  width: ScreenWidth * 45 / 100,
                  height: ScreenHeight * 15 / 100,
                  bottom: ScreenHeight * 29 / 100,
                  backgroundColor: '#38383B', borderRadius: 20, borderWidth: 0.1, borderColor: '#38383B', left: ScreenWidth * 4 / 100, alignItems: 'center'
                }}>

                  <Icon name="group" style={{
                    color: '#fee140',
                    top: ScreenHeight * 4.9 / 100,
                    right: ScreenWidth * 10 / 100
                  }}
                    size={40}
                  />

                  <View style={{ width: ScreenWidth * 30 / 100, alignItems: 'center', left: ScreenWidth * 7.7 / 100, bottom: ScreenHeight * 0.7 / 100 }}>
                    <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140' }}>  {this.state.lblvisitor}</Text>
                    <Text style={{ top: ScreenHeight * 2 / 100, fontSize: 9, color: '#fee140' }}> Jumlah visitor</Text>

                  </View>

                </View>
              </View>
            </ScrollView>
          </View>
        </ImageBackground>
      </View>



    );
  }
}
const styles = StyleSheet.create({

  butttonstyle: {
    borderRadius: 30,
    borderWidth: 0.5,
    width: ScreenWidth * 32 / 100,
    height: ScreenHeight * 10 / 100,
    borderColor: '#38383B',
    backgroundColor: '#38383B',
    alignItems: 'center'


  },


  View1: {
    width: ScreenWidth,
    height: ScreenHeight * 120 / 100,
    bottom: ScreenHeight * 15 / 100,
    left: ScreenWidth * 12 / 100,
    backgroundColor: 'transparent',

    flex: 1

  },
})
function mapStateToProps(state) {
  return {
    username: state.username,
    password: state.password,
    subsystemid: state.subsystemid,
    pwDecrypt : state.PasswordDecrypt
  }
}
function mapDispatchToProps(dispatch) {
  return {
    setUsername: (username) => {
      dispatch(setUsername(username))
    },
    setPassword: (password) => {
      dispatch(setPassword(password))
    },
    setSubSystemID: (subsystemid) => {
      dispatch(setSubSystemID(subsystemid))
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Register)