const initialState = {
    username: '',
    password: '',
    subsystemid: '',
    finalid: '',
    PasswordDecrypt:'' ,
    memoId_Choosen : '' ,
    memoidchoosen  : '',
    totalemail : ''
}

export default function reducer(state = initialState, action) {
    switch (action.type) {
        case 'setUsername':
            return {
                ...state,
                username: action.payload,
            }

        case 'setPassword':
            return {
                ...state,
                password: action.payload,
            }

        case 'setSubSystemID':
            return {
                ...state,
                subsystemid: action.payload,
            }
        case 'PasswordDecrypt':
            return {
                ...state,
                PasswordDecrypt: action.payload,
            }
        case 'setFinalID':
            return {
                ...state,
                finalid: action.payload,
            }
        case 'setMemoID' :
            return{
                ...state,
                memoidchoosen : action.payload
            }
        case 'setemail':
            return{
                ...state,
                totalemail : action.payload
            }

    }
}