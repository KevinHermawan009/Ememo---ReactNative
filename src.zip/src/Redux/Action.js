export function setUsername ( username ) {
    return {
        type : 'setUsername' ,
        payload : username
    }
}

export function setPassword ( password ) {
    return {
        type : 'setPassword' ,
        payload : password
    }
}

export function setMemoID ( memoidchoosen ) {
    return {
        type : 'setMemoID' ,
        payload : memoidchoosen
    }
}

export function setSubSystemID ( subsystemid ) {
    return {
        type : 'setSubSystemID' ,
        payload : subsystemid
    }
}
export function setPasswordDecrypt ( PasswordDecrypt ) {
    return {
        type : 'PasswordDecrypt' ,
        payload : PasswordDecrypt
    }
}
export function setFinalID(finalid){
    return{
        type : 'setFinalID',
        payload: finalid
    }
}

export function setMemoIDChoosen ( memoID_Choosen ) {
    return {
        type : 'SET_MEMO_ID_CHOOSEN',
        payload : memoID_Choosen
    }
}
// export function setmemoid(memoidchoosen){
//     return{
//         type : 'setmemoid',
//         payload: memoidchoosen
//     }
// }

export function setDtDetail ( DtDetail ) {
    return {
        type : 'setDtDetail',
        payload : DtDetail
    }
}

export function setDtSupportDetail ( DtSupportDetail ) {
    return {
        type : 'setDtSupportDetail',
        payload : DtSupportDetail
    }
}

export function setDtAttachment ( DtAttachment ) {
    return {
        type : 'setDtAttachment',
        payload : DtAttachment
    }
}

export function setDtApprovalScheme ( DtApprovalScheme ) {
    return {
        type : 'setDtApprovalScheme',
        payload : DtApprovalScheme
    }
}
export function setemail(totalemail){
    return{
        type:'setemail',
        payload: totalemail
    }
}