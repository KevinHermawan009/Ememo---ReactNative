import React, { Component } from 'react';
import { Router, Stack, Scene, Actions, Drawer } from 'react-native-router-flux';
import { Image, AsyncStorage, TouchableOpacity, renderTitle, ImageBackground, Text, View, Dimensions } from 'react-native';
import Login from '../pages/login';
import Loadingpage from '../pages/loadingpage';
import Register from '../pages/register';
// import Sidebar from '../components/Sidebar';
import TabIcon1 from '../components/TabIcon1';
import Tabicon2 from '../components/Tabicon2';
import Tabicon3 from '../components/Tabicon3';
import Tabicon4 from '../components/Tabicon4';
import Tabicon5 from '../components/Tabicon5';
import History from '../components/History';
import Email1 from '../pages/Email1';
import Cuti from '../components/Cuti';
import Memo from '../components/Memo';
import Profile from '../components/Profile';
import Icon from 'react-native-vector-icons/FontAwesome';


const ScreenWidth = Dimensions.get('window').width;
const ScreenHeight = Dimensions.get('window').height;
export default class Root extends Component {


    loginPressed = () => {
        Actions.login()
    }

    burgerPressed() {
        Actions.drawerOpen()
    }
    logOut = async () => {
        try {
            const remove = await AsyncStorage.removeItem('key1');
            const remove1 = await AsyncStorage.removeItem('key2');
            const remove2 = await AsyncStorage.removeItem('key3');
            const value = await AsyncStorage.getItem('key1');
            const value1 = await AsyncStorage.getItem('key2');
            const value2 = await AsyncStorage.getItem('key3');
            Actions.login()
        } catch (error) {
            alert("Error resettting data" + error);
        }
    }
    render() {
        return (
            <Router>
                <Stack
                    key="root"
                    hideNavBar={true}
                    navigationBarStyle={{ backgroundColor: '#38383B', height: ScreenHeight * 9 / 100 }}>
                    <Scene component={Loadingpage} key='loadingpage' />

                    <Scene initial={true} component={Login} key='login' type = 'reset'/>
                    {/* <Drawer
                        // renderLeftButton={
                        //     <TouchableOpacity onPress={this.burgerPressed}>
                        //          <Icon name='bars' 
                        //     style={{ 
                        //     marginLeft:ScreenWidth*5/100,
                    
                           
                        //     fontSize:30,
                        //     color: '#fee140' }} />
                        //     </TouchableOpacity>
                        // // }
                        // hideNavBar={true}
                        // key="sidebar"
                        // contentComponent={Sidebar}
                        drawerWidth={ScreenWidth*85/100}
                        drawerPosition="left"> */}
                    <Scene
                        tabs
                        key="tabs"
                        hideNavBar={true}
                        style={{ width: ScreenWidth * 13 / 100 }}
                        type='reset'
                        inactiveTintColor='white'
                        activeTintColor='#fee140'
                        inactiveBackgroundColor='#38383B'
                        tabBarStyle={{ fontSize: 100, backgroundColor: '#C0C0C0', height: ScreenHeight * 10 / 100 }}

                        renderTitle={
                            <View>
                                <ImageBackground
                                    source={require('../image/maybankkuning1.png')}
                                    style={{
                                        width: ScreenWidth * 62 / 100,
                                        height: ScreenHeight * 7.8 / 100,
                                        left: ScreenWidth * 4 / 100,
                                        marginTop: ScreenHeight * 3.5 / 100

                                    }}
                                >
                                </ImageBackground>
                                <View style={{ marginTop: ScreenHeight * -3 / 100 }}>
                                    <TouchableOpacity
                                        style={{
                                            backgroundColor: 'transparent',
                                            left: ScreenWidth * 85 / 100,
                                            top: ScreenHeight * -3.5 / 100,
                                            height: ScreenHeight * 6.5 / 100,
                                            width: ScreenWidth * 55 / 100,
                                        }}
                                        onPress={this.logOut}
                                    >
                                        <Icon name="sign-out" style={{ color: '#fee140' }} size={30} />
                                    </TouchableOpacity>
                                </View>
                            </View>
                        }
                    >
                        <Scene
                            key='Tab1'
                            title='EMAIL'
                            iconName='envelope'
                            icon={TabIcon1}
                            barColor='mediumseagreen'
                            hideNavBar={false}
                            component={Email1} />

                        <Scene
                            key='Tab2'

                            iconName='Calendar'
                            title='CUTI'
                            icon={Tabicon2}
                            hideNavBar={false}
                            barColor='dodgerblue'
                            pressColor='rgba(255, 255, 255, 0.16)'
                            component={Cuti} />

                        <Scene
                            key='Tab3'
                            title='HOME'
                            iconName='home'
                            icon={Tabicon3}
                            hideNavBar={false}
                            barColor='tomatoe'
                            pressColor='rgba(255, 255, 255, 0.16)'
                            component={Register} />

                        <Scene
                            key='Tab4'
                            title='HISTORY'
                            iconName='history'
                            icon={Tabicon4}
                            hideNavBar={false}
                            barColor='tomatoe'
                            pressColor='rgba(255, 255, 255, 0.16)'
                            component={History} />

                        <Scene
                            key='Tab5'
                            title='PROFILE'
                            iconName='user-o'
                            icon={Tabicon5}
                            hideNavBar={false}
                            barColor='tomatoe'
                            pressColor='rgba(255, 255, 255, 0.16)'
                            component={Profile} />
                    </Scene>
                    <Scene component={Register} key='register' />
                    <Scene component={Cuti} key='Cuti' />
                    <Scene component={Memo} key='Memo' />
                    <Scene component={Profile} key='Profile' />
                    {/* </Drawer> */}
                </Stack>
            </Router >
        );
    }

}